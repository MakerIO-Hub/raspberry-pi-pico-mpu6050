import time
from machine import Pin
import framebuf

class ILI9341(framebuf.FrameBuffer):
    def __init__(self, spi, cs, dc, rst, w=240, h=320, r=0):
        self.spi = spi
        self.cs = cs
        self.dc = dc
        self.rst = rst
        self.width = w
        self.height = h
        self.buffer = bytearray(self.width * self.height * 2)
        super().__init__(self.buffer, self.width, self.height, framebuf.RGB565)
        self.init_display()

    def write_cmd(self, cmd):
        self.dc(0); self.cs(0); self.spi.write(bytearray([cmd])); self.cs(1)

    def write_data(self, buf):
        self.dc(1); self.cs(0); self.spi.write(buf); self.cs(1)

    def init_display(self):
        self.rst(1); time.sleep(0.05); self.rst(0); time.sleep(0.1); self.rst(1); time.sleep(0.2)
        self.write_cmd(0x01); time.sleep(0.5)
        self.write_cmd(0x11); time.sleep(0.2)
        self.write_cmd(0x3A); self.write_data(b'\x55')
        self.write_cmd(0x36); self.write_data(b'\x48')
        self.write_cmd(0x29); time.sleep(0.2)

    def show(self):
        self.write_cmd(0x2A); self.write_data(bytearray([0x00, 0x00, (self.width - 1) >> 8, (self.width - 1) & 0xFF]))
        self.write_cmd(0x2B); self.write_data(bytearray([0x00, 0x00, (self.height - 1) >> 8, (self.height - 1) & 0xFF]))
        self.write_cmd(0x2C); self.dc(1); self.cs(0); self.spi.write(self.buffer); self.cs(1)