from machine import I2C, Pin, SPI, PWM
import time, struct, random, math
from ili9341 import ILI9341

# --- DONANIM ---
i2c = I2C(0, scl=Pin(1), sda=Pin(0), freq=400000)
try: i2c.writeto_mem(0x68, 0x6B, b'\x00')
except: pass
spi = SPI(0, baudrate=40000000, sck=Pin(18), mosi=Pin(19))
display = ILI9341(spi, Pin(17), Pin(21), Pin(20), 240, 320)

btn_up = Pin(10, Pin.IN, Pin.PULL_UP)
btn_down = Pin(11, Pin.IN, Pin.PULL_UP)
btn_action = Pin(12, Pin.IN, Pin.PULL_UP) 

buzzer = PWM(Pin(15))
buzzer.freq(1000); buzzer.duty_u16(0)

# --- OYUN AYARLARI ---
px, py = 120.0, 260.0 
ACCEL, score, lives = 35.0, 0, 3
bullets, enemies, rockets = [], [], []
state = "MENU"
menu_idx = 0
menu_items = ["START GAME", "SETTINGS"]
last_fire, start_ticks = 0, time.ticks_ms()
invincible_until = 0
stars = [[random.randint(0, 240), random.randint(0, 320)] for _ in range(40)]
continue_start = 0

def draw_jet(x, y, color, flicker=False):
    if flicker and (time.ticks_ms() // 150) % 2 == 0: return
    display.fill_rect(int(x)-3, int(y), 6, 25, color)
    display.fill_rect(int(x)-16, int(y)+8, 32, 6, color)
    display.fill_rect(int(x)-2, int(y)+3, 4, 6, 0xFFFF)
    display.fill_rect(int(x)-3, int(y)+25, 6, 4, 0xFFE0)

def draw_enemy(x, y):
    display.fill_rect(int(x)-4, int(y), 8, 16, 0x001F)
    display.fill_rect(int(x)-10, int(y)+4, 20, 3, 0x07E0)

def draw_rocket(x, y):
    color = 0xFC60
    display.fill_rect(int(x)-2, int(y)-8, 4, 16, color)
    display.fill_rect(int(x)-6, int(y), 12, 4, color)
    display.pixel(int(x), int(y)-10, 0xFFFF)

while True:
    curr = time.ticks_ms()
    display.fill(0)
    for s in stars:
        s[1] = int((s[1] + 2) % 320)
        display.pixel(int(s[0]), s[1], 0xFFFF)

    if state == "MENU":
        # BÜYÜK VE KALIN BAŞLIK
        display.text("SHOOTER PI", 70, 40, 0xF800)
        display.text("SHOOTER PI", 71, 40, 0xF800)
        display.text("SHOOTER PI", 70, 41, 0xF800)
        
        for i, item in enumerate(menu_items):
            color = 0xF800 if i == menu_idx else 0xFFFF
            display.text("> " + item if i == menu_idx else "  " + item, 60, 130 + (i*40), color)
        
        if btn_up.value() == 0: menu_idx = 0; time.sleep(0.2)
        if btn_down.value() == 0: menu_idx = 1; time.sleep(0.2)
        if btn_action.value() == 0:
            if menu_idx == 0: state = "PLAYING"; start_ticks = curr; score=0; lives=3; px=120
            time.sleep(0.3)
            
    elif state == "GAMEOVER":
        display.text("GAME OVER", 80, 120, 0xF800)
        remaining = 10 - ((curr - continue_start) // 1000)
        display.text("CONTINUE: " + str(max(0, remaining)), 70, 160, 0xFFFF)
        if remaining <= 0: state = "MENU"; score = 0
        if btn_action.value() == 0:
            state = "PLAYING"; lives = 3; score = max(0, score - 50); enemies.clear(); bullets.clear(); rockets.clear()
            time.sleep(0.3)

    else: # PLAYING
        if btn_action.value() == 0 and curr - last_fire > 250:
            bullets.append([px, py-10]); buzzer.freq(600); buzzer.duty_u16(15000)
            time.sleep(0.02); buzzer.duty_u16(0); last_fire = curr
        
        wave = 1 + (score // 100)
        diff = 1.0 + (wave - 1) * 0.4 
        spawn_rate = 0.05 if score < 300 else 0.12
        
        try:
            val = struct.unpack('>h', i2c.readfrom_mem(0x68, 0x3D, 2))[0] / 16384.0
            px = max(30, min(210, px + (val * ACCEL)))
        except: pass
        
        elapsed = (curr - start_ticks) // 1000
        mins = (elapsed // 60) % 60
        secs = elapsed % 60
        
        # HİZALAMA: S(Sol), L(Orta), T(Sağ)
        display.text("S:{}".format(score), 5, 5, 0x07E0)
        display.text("L:{}".format(lives), 115, 5, 0x07E0)
        display.text("T:{:02d}:{:02d}".format(mins, secs), 175, 5, 0x07E0)
        
        draw_jet(px, py, 0xF800, flicker=(curr < invincible_until))
        
        if random.random() < spawn_rate * diff: enemies.append([float(random.randint(30, 210)), 0.0])
        if score >= 150 and random.random() < 0.02 * diff: rockets.append([float(random.randint(30, 210)), 0.0])
        
        for b in bullets[:]:
            b[1] -= 15; display.fill_rect(int(b[0]), int(b[1]), 3, 10, 0x07E0)
            if b[1] < 0: bullets.remove(b)
        
        for e in enemies[:]:
            e[1] += 4 * diff; e[0] += math.sin(e[1] / 20) * 2
            draw_enemy(e[0], e[1])
            for b in bullets[:]:
                if abs(e[0]-b[0]) < 20 and abs(e[1]-b[1]) < 20:
                    enemies.remove(e); bullets.remove(b); score += 10; break
            if curr > invincible_until and abs(e[0]-px) < 25 and abs(e[1]-py) < 25:
                lives -= 1; invincible_until = curr + 2000; enemies.remove(e)
            if e[1] > 320: enemies.remove(e)
            
        for r in rockets[:]:
            r[1] += 10 * diff; draw_rocket(r[0], r[1])
            if curr > invincible_until and abs(r[0]-px) < 20 and abs(r[1]-py) < 20:
                lives -= 1; invincible_until = curr + 2000; rockets.remove(r)
            if r[1] > 320: rockets.remove(r)
            
        if lives <= 0: state = "GAMEOVER"; continue_start = curr
    display.show()